<?php

function bar() {
    foo($_GET['name']);
}

function foo($name) {
    mysql_query("SELECT * FROM foo WHERE name = '$name'");
}

$var7 = $_GET["p"];
$var4 = $var7;
echo "$var4";