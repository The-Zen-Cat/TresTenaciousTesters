from console_gfx import ConsoleGfx


def menu():
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")
    print("Select a Menu Option: ")

def main():
    user_select = 999
    image = 0
    print("Welcome to the RLE image encoder: \n")
    print("Displaying Spectrum Image: ")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    while user_select != 0:
        menu()
        user_select = int(input())
        if user_select == 1:
            print("Enter name of file to load: ")
            file_name = input()
            image = ConsoleGfx.load_file(file_name)
        elif user_select == 2:
            image = ConsoleGfx.test_image
            print("Test image loaded")
        elif user_select == 6:
            ConsoleGfx.display_image(image)
main()

