from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''
# function definitions
def count_runs(flat):
    pass

test_image = None

if __name__ == '__main__':
    # Main program
    # Welcomes message
    print("Welcome to the RLE image encoder!")
    # Display color test
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    # Display menu
    menu_option = -1
    # use while loop to have the user be prompted to continue choosing options
    while menu_option != 0:
        print()
        print("RLE Menu")
        print("-" * 8)
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print()
        menu_option = int(input("Select a Menu Option:"))
        if menu_option == 1:
            # prompt user for file name
            filename = input("Enter name of file to load:")
            # call ConsoleGfx.load_file and store returned value in image_data
            test_image = ConsoleGfx.load_file(filename)

        elif menu_option == 2:
            # create a variable where ConsoleGfx.test_image is stored in image_data
            test_image = ConsoleGfx.test_image
            print("Test image data loaded.")

        elif menu_option == 6:
            # call display_image in ConsoleGfx on image_data
            print("Displaying image...")
            ConsoleGfx.display_image(test_image)

