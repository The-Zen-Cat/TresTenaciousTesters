from console_gfx import ConsoleGfx


if __name__ == '__main__':
    # main program
    image_data = None
    # prints welcome messages and displays test rainbow
    print("Welcome to the RLE image encoder!")
    print("\nDisplaying Spectrum Image:")

    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu = -1

    while menu != 0:
        # print menu
        print("\nRLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")

        menu_option = input("\nSelect a Menu Option: ")

        # menu option 1
        if menu_option == "1":
            filename = input("Enter name of the file to load: ")
            image_data = ConsoleGfx.load_file(filename)
        # menu option 2
        elif menu_option == "2":
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
        # menu option 3
        elif menu_option == "6":
            print("Displaying image...")
            ConsoleGfx.display_image(image_data)
            menu = 0
