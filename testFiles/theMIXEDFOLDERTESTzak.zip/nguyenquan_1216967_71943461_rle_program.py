from console_gfx import ConsoleGfx


def main():
    print("Welcome to the RLE image encoder!\nDisplaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()
    menu = True
    while menu == True:
        print("RLE Menu")
        print("*" * 8)
        print("0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLD String\n4. Read RLE Hex String")
        print("5. Read Data Hex String\n6. Display Image\n7. Display RLE String")
        print("8. Display Hex RLE Data\n9. Display Hex Flat Data\n")
        choice = int(input("Select a Menu Option: "))
        if choice < 0 or choice > 9:
            print("Error! Invalid input.\n")
            continue
        if choice == 0:
            quit()
        elif choice == 1:
            img = input("Enter name of file to load: ")
            pix = ConsoleGfx.load_file(img)
        elif choice == 2:
            pix = ConsoleGfx.test_image
            print("Test image data loaded.")
        elif choice == 3:
            pass
            rlestr = input("Enter an RLE String to be decoded")
        elif choice == 4:
            pass
            rlehex = input("Enter the hex string holding RLE data: ")
        elif choice == 5:
            pass
            rle_flathex = input("Enter the hex string holding flat data:")
        elif choice == 6:
            print("Displaying image...")
            if not pix:
                print("(no data)\n")
            else:
                ConsoleGfx.display_image(pix)
        elif choice == 7:
            pass
        elif choice == 8:
            pass
        elif choice == 9:
            pass


main()
