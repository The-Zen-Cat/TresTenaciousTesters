from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''
# function definitions
def count_runs(flat):
    pass



if __name__ == '__main__':
    # main program
    image_data = None

    print('Welcome to the RLE image encoder!')

    print('\nDisplaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. use while loop to keep prompting the user to choose a menu option
    menu = -1
    while menu != 0:

        print('RLE Menu')
        print('--------')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8. Display Hex RLE Data')
        print('9. Display Hex Flat Data')

        menu = int(input('\nSelect a Menu Option: '))

        if menu == 0:
            break

        if menu == 1:
            # load file and store the data inside image_data
            filename = input('Enter name of file to load: ')
            image_data = ConsoleGfx.load_file(filename)

        if menu == 2:
            # store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image

        if menu == 6:
            # call display_image in ConsoleGfx on image_data
            print('Displaying image...')
            ConsoleGfx.display_image(image_data)
