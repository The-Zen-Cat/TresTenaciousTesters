from console_gfx import ConsoleGfx


def count_runs(flat):
    pass

if __name__ == '__main__':
    image_data = None
    print("Welcome to the RLE image encoder!")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print("")
    print("")
    menu = -1
    while menu != 0:
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display HEX RLE Data")
        print("9. Display HEX Flat Data")
        menu = int(input("Select a Menu Option:"))
        if menu == 1:
            file_name = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(file_name)
        elif menu == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
        elif menu == 6:
            ConsoleGfx.display_image(image_data)
