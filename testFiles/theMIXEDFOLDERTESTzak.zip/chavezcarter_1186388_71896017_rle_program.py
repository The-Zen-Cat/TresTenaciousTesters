from console_gfx import ConsoleGfx







if __name__ ==  '__main__':
    # Main program
    image_data = None
    #1. welcome message
    #2. display the test rainbow
    print("Welcome to the RLE image encoder!")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")


    #3. use while loop to keep prompting the user to choose a menu option


    menu = -1

    while menu != 0:
        menu_option = int(input("Select a Menu Option:"))
        if menu_option == 1:
            user_file = input("Enter name of file to load:")
            image_data = ConsoleGfx.load_file(user_file)

        elif menu_option == 2:
            image_data = ConsoleGfx.test_image
            print("Test Image data loaded.")
        elif menu_option == 6:
            if image_data:
                ConsoleGfx.display_image(image_data)


