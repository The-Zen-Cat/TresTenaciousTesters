from console_gfx import ConsoleGfx


def main():
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    # loaded_image should always be a decoded list, initialize to none for option 6 check
    loaded_image = None
    while True:
        print("\nRLE Menu\n"
              "--------\n"
              "0. Exit\n"
              "1. Load File\n"
              "2. Load Test Image\n"
              "3. Read RLE String\n"
              "4. Read RLE Hex String\n"
              "5. Read Data Hex String\n"
              "6. Display Image\n"
              "7. Display RLE String\n"
              "8. Display Hex RLE Data\n"
              "9. Display Hex Flat Data\n")
        option = input("Select a Menu Option: ")
        if option == "0":
            exit()
        elif option == "1":
            file_name = input("Enter name of file to load: ")
            loaded_image = ConsoleGfx.load_file(file_name)
        elif option == "2":
            loaded_image = ConsoleGfx.test_image
            print("Test image data loaded.")
        elif option == "6":
            print("Displaying image...")
            if loaded_image is None:
                print("(no data)")
            else:
                ConsoleGfx.display_image(loaded_image)
        else:
            print("Error! Invalid input.")


if __name__ == "__main__":
    main()
