from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''

def count_runs(flat):
    pass


if __name__ == '__main__':
    # main program
    image_data = None
    # 1. welcome messages
    print("Welcome to the RLE image encoder!")
    # 2. display the test_rainbow
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. use while loop to keep prompting the user to choose a new menu option
    menu = -1
    while menu != 0:
        print("RLE Menu")
        print("--------")
        print("0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String")
        print("4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image")
        print("7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data")

        # 4. prompt the user for menu option
        menu_option = int(input("Select a Menu Option:"))

        # option 1
        if menu_option == 1:
            # load file and store data inside image_data
            # prompt for the file name
            filename = input("Enter name of file to load:")
            # call ConsoleGfx.load_file(filename) and store returned value in image_data
            image_data = ConsoleGfx.load_file(filename)

        # option 2
        if menu_option == 2:
            print("Test image data loaded.")
            # store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image

        # option 6
        if menu_option == 6:
            print("Displaying image...")
            # call display_image in ConsoleGfx in image_data
            image_data = ConsoleGfx.display_image
