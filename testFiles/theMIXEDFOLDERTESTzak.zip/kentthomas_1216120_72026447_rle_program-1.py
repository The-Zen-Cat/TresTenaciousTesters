from console_gfx import ConsoleGfx

# We split the welcome text into two separate parts as the spectrum must be displayed between the first and
# second text blocks. Also, the options must be repeated displayed to the user.
WELCOME = "Welcome to the RLE image encoder!\n\nDisplaying Spectrum Image:"

OPTIONS = """
RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data

Select a Menu Option: """


# Since this is a larger project, we will use a main function to enforce local scope.
def main():
    """Main function for run-length encoding."""

    image_data = None

    def prompt_options(options: str) -> str:
        """Displays program options to the user, prompts user for input, and returns that input."""

        print("\n", options, sep='', end='')
        selection = input()
        return selection

    print(WELCOME)
    # Display the spectrum using data stored in the console_gfx module and calling the display_image method.
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    still_selecting = True
    while still_selecting:
        usr_selection = prompt_options(OPTIONS)

        # To exit the program we simply terminate the main loop.
        if usr_selection == "0":
            still_selecting = False

        # We decode the .gfx file using the console_gfx module and store it in memory.
        elif usr_selection == "1":
            image_data = ConsoleGfx.load_file(input("Enter name of file to load: "))

        # If the user wants to load the test tile, we simply store it in memory by accessing its location in
        # the console_gfx module.
        elif usr_selection == "2":
            image_data = ConsoleGfx.test_image

        # Todo 3: Read RLE String.

        # Todo 4: Read RLE Hex String.

        # Todo 5: Read Data Hex String.

        # First, check to see if an image was loaded. If image_data is None, no image was stored in memory. If an
        # image was stored in memory, display that image by calling display_image method from console_gfx module.
        elif usr_selection == "6":
            if image_data is None:
                print("""
                Displaying image...
                (no data)""")
            else:
                print("Displaying image...")
                ConsoleGfx.display_image(image_data)

        # Todo 7: Display RLE String.

        # Todo 8: Display Hex RLE Data.

        # Todo 9: Display Hex Flat Data.

        # The only valid inputs for usr_selection are str values "1" to "9".
        else:
            print("Error! Invalid input.")


# Enforce local scope using the special variable __name__.
if __name__ == "__main__":
    main()
