# Landon McIntosh
# COP 3502C - Project 2A
# October 4, 2022

from console_gfx import ConsoleGfx as cgfx
# above line imports console_gfx class


# below line defines function for printing the menu that will be used a lot
def print_menu():
    print("RLE Menu")
    print("--------")
    print("0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String")
    print("5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex "
          "Flat Data\n")
    slay = int(input("Select a Menu Option: "))  # asks user to select a menu option

    return slay  # returns selected menu option


def main():
    # prints welcome message
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")

    cgfx.display_image(cgfx.test_rainbow)

    print()
    print()
    opt = print_menu()

    image = []  # defines image as an empty list

    while opt > 0:  # while loop until option 0 creates exit from program

        if opt == 1:  # option 1 loads files
            image.extend(cgfx.load_file(input("Enter name of file to load: ")))  # adds image file to list image[]
        elif opt == 2:  # option 2 loads the test image
            image.extend(cgfx.test_image)
            print('Test image data loaded.')  # adds image file to list image[]
            print()
        elif opt == 3:
            pass
        elif opt == 4:
            pass
        elif opt == 5:
            pass
        elif opt == 6: # option 6 displays the loaded image
            cgfx.display_image(image)
            print()
        elif opt == 7:
            pass
        elif opt == 8:
            pass
        elif opt == 9:
            pass
        else:
            print("Error! Invalid Selection. Please select another option.")
            print()

        opt = print_menu()
        print()



if __name__ == '__main__':
    main()
