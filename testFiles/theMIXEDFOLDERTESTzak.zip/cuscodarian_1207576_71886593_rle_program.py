##Immport method from console_gfx
from console_gfx import ConsoleGfx

# Create a method that prints the menu
def menu_option():
    print('RLE Menu\n'
          '--------\n'
          '0. Exit\n'
          '1. Load File\n'
          '2. Load Test Image\n'
          '3. Read RLE String\n'
          '4. Read RLE Hex String\n'
          '5. Read Data Hex String\n'
          '6. Display Image\n'
          '7. Display RLE String\n'
          '8. Display Hex RLE Data\n'
          '9. Display Hex Flat Data\n')

if __name__ == '__main__':
    #main program
    image_data = None
    menu_choice = 0
    print('Welcome to the RLE image encoder!\n')

    #display the test_rainbow
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()


    menu_continue = True
    while menu_continue:
        menu_option()
        menu_choice = int(input('Select a Menu Option: '))
        if menu_choice == 1:
            # Prompt for file name
             file_name = input('Enter name of file to load: ')
            # Load file and store the data inside image_data
            # call ConsoleGfx.load_file(filename) and store returned value in image_data
             image_data = ConsoleGfx.load_file(file_name)
        if menu_choice == 2:
            #store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image
            print('Test image data loaded.\n')
        if menu_choice == 6:
            print('Displaying Image...')
            #Display image_data using display_image method from ConsoleGfx
            ConsoleGfx.display_image(image_data)
            print()



