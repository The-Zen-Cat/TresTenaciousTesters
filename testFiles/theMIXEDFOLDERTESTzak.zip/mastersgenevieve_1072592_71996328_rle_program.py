#importing consolegfx
import console_gfx as ConsoleGfx
ConsoleGfx = ConsoleGfx.ConsoleGfx

#stand alone menu
print('Welcome to the RLE image encoder!')
print(' ')
print('Displaying Spectrum Image:')
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
print(' ')
menu = """RLE MENU
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data
 """
while True:
    print(menu)
    user_input = int(input('Select a Menu Option: '))
    if user_input == 1:
        image_data = str(input('Enter name of file to load: '))
        print(' ')
        choice = 1
        continue
    if user_input == 2:
        ConsoleGfx.test_image
        print('Test image data loaded.')
        print(' ')
        choice = 2
        continue
    if user_input == 6:
        print('Displaying image . . .')
        if choice == 1:
            ConsoleGfx.display_image(ConsoleGfx.load_file(image_data))
            print(' ')
            continue
        if choice == 2:
            ConsoleGfx.display_image(ConsoleGfx.test_image)
            print(' ')
            continue
        continue




