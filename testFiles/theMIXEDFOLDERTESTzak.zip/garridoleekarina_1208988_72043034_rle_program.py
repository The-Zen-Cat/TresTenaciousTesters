from console_gfx import ConsoleGfx

print("Welcome to the RLE image encoder!")
print(" ")
print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)  # print code here that displays the spectrum image

print('''
''')


rle_program = True
while rle_program:
    print("RLE Menu")
    print("_" * 8)
    print("0. Exit \n1. Load File \n2. Load Test Image \n3. Read RLE String \n4. Read RLE Hex String", end='')
    print(
        "\n5. Read Data Hex String \n6. Display Image \n7. Display RLE String \n8. Display Hex RLE Data \n9. Display Hex Flat Data")
    print(" ")
    menu_option = int(input("Select a Menu Option: "))
    if menu_option == 1:  # load file
        file = ConsoleGfx.load_file(filename=input("Enter name of file to load: "))  # FIXME
        continue
    if menu_option == 2:  # load test image
        print("Test image data loaded.")
        ConsoleGfx.display_image(ConsoleGfx.test_image)
        continue
    if menu_option == 3:  # read RLE string
        print("Enter an RLE string to be decoded: ")
        continue
    if menu_option == 4:  # read RLE hex string
        print("Enter the hex string holding the RLE data: ")
        continue
    if menu_option == 5:  # read data hex string
        data_hex_string = input("Enter the hex string holding flat data: ")
        continue
    if menu_option == 6:  # display image
        print("Displaying image...")
        ConsoleGfx.display_image(file)  # parameter = file name ?? FIXME
        continue
    if menu_option == 7:  # display RLE string
        rle_representation = input()  # 28:10:6b:10:10b:10:2b:10:12b:10:2b:10:5b:20:11b:10:6b:10
        print(f"RLE representation: {rle_representation}")
        continue
    if menu_option == 8:  # display hex RLE data
        print("RLE hex values: ")
        continue
    if menu_option == 9:  # display hex flat data
        flat_hex = input()
        print(f"Flat hex values: {flat_hex}")
        continue
    else:
        rle_program = False
        break
