"""
*    Title: Module M3 Lecture - Project 2A walkthrough, M3 Practice Questions, Live Coding 14.7
*    Author: Zhou, Lisha
*    Date: 2022
*    Code version: Not applicable
*    Availability: elearning.ufl.edu - COP3502 Lectures
"""


print("Welcome to the RLE image encoder!")
print()
print("Displaying Spectrum Image:")
from console_gfx import ConsoleGfx

'''
#print(ConsoleGfx.test_rainbow)
#ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''

# function definitions (will have a lot of functions to define BEFORE __name__ statement --> 8)
#def count_runs(flat):

def to_hex_string(data):
    pass
def count_runs(flat_data):
    pass
def encode_rle(flat_data):
    pass
def get_decoded_length(rle_data):
    pass
def decode_rle(rle_data):
    pass
def string_to_data(data_string):
    pass
def to_rle_string(rle_data):
    pass
def string_to_rle(rle_string):
    pass

if __name__ == '__main__':
    # main program (ie. if while loop..... )
    image_data = None
    menu = -1
    # 1. welcome message
    # 2. display the test_rainbow image
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    # print("RLE Menu")
    # print("-" * 8)
    # print("0. Exit")
    # print("1. Load File")
    # print("2. Load Test Image")
    # print("3. Read RLE String")
    # print("4. Read RLE Hex String")
    # print("5. Read Data Hex String")
    # print("6. Display Image")
    # print("7. Display RLE String")
    # print("8. Display Hex RLE Data")
    # print("9. Display hex Flat Data")
    # print()
    # menu = int(input("Select a Menu Option: "))

    #3 use while loop to keep prompting user to choose a menu option

    while menu != 0:
        #4 prompt user for menu option
        print()
        print()
        print("RLE Menu")
        print("-" * 8)
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display hex Flat Data")
        print()
        menu = int(input("Select a Menu Option: "))
        if menu == 1:
            file_to_load = input("Enter name of file to load:")
            ConsoleGfx.test_image = ConsoleGfx.load_file(file_to_load)
            continue
        # option 1
            # load file and store the data inside the image_data
                # prompt for the file name
                # call ConsoleGfx.load_file(filename) and store returned value in image_data

        elif menu == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
            continue
        # option 2
            # store ConsoleGfx.test_image in image_data

        elif menu == 6:
            ConsoleGfx.display_image(image_data)

        # option 6
            # call display_image in ConsoleGfx on image_data
        pass

