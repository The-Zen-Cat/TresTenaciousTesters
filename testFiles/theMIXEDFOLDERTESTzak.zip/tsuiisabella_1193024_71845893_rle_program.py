'''
P2: RLE with Images Python
    - implement encoding and decoding of raw data
    - conversion between data and strings
    - display of information
    - by creating procedures: can be called from within the programs and externally
Goal: Practice with loops, strings, Python lists, methods, and type-casting
'''

# import ConsoleGfx class from console_gfx.py module
from console_gfx import ConsoleGfx

# welcome message with spectrum image
def welcome():
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print('\n')

# show RLE menu
def menu():
    print('\nRLE Menu')
    print('-' * 8)
    print(
          '0. Exit\n'
          '1. Load File\n'
          '2. Load Test Image\n'
          '3. Read RLE String\n'
          '4. Read RLE Hex String\n'
          '5. Read Data Hex String\n'
          '6. Display Image\n'
          '7. Display RLE String\n'
          '8. Display Hex RLE Data\n'
          '9. Display Hex Flat Data\n'
          )

# get menu option
def get_menu_option():
    menu_option = input('Select a Meun Option: ')
    return menu_option

# aid debugging: translate (RLE or raw) data, a hexadecimal string without delimiters
def to_hex_string(data):
    pass

# return number of runs of data in an image data set; double this result for length of encoded RLE list
def count_runs(flat_data):
    pass

# return encoding in RLE of the raw data passed in; used to generate RLE representation of a data
def encode_rle(flat_data):
    pass

# return decompressed size RLE data; used to generate flat data from RLE encoding. (Counterpart to count_runs)
def get_decoded_legth(rle_data):
    pass

# return the decoded data set from RLE encoded data; decompress RLE data for use. (Inverse of encode_rle)
def decode_rle(rle_data):
    pass

# translates a string in hexadecimal format into byte (RLE or raw) data. (Inverse of to_hex_string)
def string_to_data(data_string):
    pass

# translates RLE data into a human-readable representation.
# for each run, in order, display run length in decimal (1-2 digits)
# run value in hexadecimal (1 digit)
# a delimiter, ':', between runs
def to_rle_string(rle_data):
    pass

# translates a string in human-readable RLE format with delimiter into RLE byte data. (Inverse of to_rle_string)
def string_to_rle(rle_string):
    pass

# main function
def main():
    # variables
    image_data = []
    menu_option = ''
    # print welcome message
    welcome()
    # loop the program until menu_option is '0'
    while menu_option != '0':
        # print RLE menu
        menu()
        # get menu_option
        menu_option = get_menu_option()
        # check input is invalid
        if menu_option not in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
            print('Error! Invalid input.')
        # if input is valid
        else:
            # for menu_option is '1'
            if menu_option == '1':
                # assign input to filename
                filename = input('Enter name of file to load: ')
                # check input is invalid
                if filename not in ['testfiles/fsu.gfx', 'testfiles/gator.gfx', 'testfiles/lsu.gfx',
                                    'testfiles/uga.gfx', 'testfiles/ut.gfx']:
                    print('Error! Invalid input.')
                # if input is valid
                else:
                    # load image data from file
                    image_data = ConsoleGfx.load_file(filename)
            # for menu_option is '2'
            elif menu_option == '2':
                # load test image
                image_data = ConsoleGfx.test_image
                print('Test image data loaded.')
            # for menu_option is '3'
            elif menu_option == '3':
                pass
            # for menu_option is '4'
            elif menu_option == '4':
                pass
            # for menu_option is '5'
            elif menu_option == '5':
                pass
            # for menu_option is '6'
            elif menu_option == '6':
                # check if image_data is empty
                if image_data == []:
                    # show no data message
                    print('Displaying image...\n'
                          '(no data)')
                # if image_data is not empty
                else:
                    # display image
                    print('Displaying image...')
                    ConsoleGfx.display_image(image_data)

            elif menu_option == '7':
                # check if image_data is empty
                if image_data == []:
                    # show no data message
                    print('RLE representation: (no data)')
                else:
                    pass

            elif menu_option == '8':
                # check if image_data is empty
                if image_data == []:
                    # show no data message
                    print('RLE hex values: (no data)')
                else:
                    pass

            elif menu_option == '9':
                # check if image_data is empty
                if image_data == []:
                    # show no data message
                    print('Flat hex values: (no data)')
                else:
                    pass


if __name__ == '__main__':
    # run the main script
    main()