#Importing Modules
import console_gfx
cg = console_gfx.ConsoleGfx
#Setting variables
file = []
#Menu Creation
print("Welcome to the RLE Image Encoder")
cg.display_image(cg.test_rainbow)
print("\nRLE Menu\n--------\n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex "
      "String\n5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display "
      "Hex Flat Data")
#Loop through options till user exits
while True:
    menu_choice = int(input("Select a Menu Option: "))
    if menu_choice == 0:
        exit()
    #Loads file
    elif menu_choice == 1:
        file = cg.load_file(input("Enter name of file to load: "))
    #Loads test image
    elif menu_choice == 2:
        file = cg.test_image
        print("Test image data loaded")
    #Displays image based on array of decoded bytes
    elif menu_choice == 6:
        cg.display_image(file)


