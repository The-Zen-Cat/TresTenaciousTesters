from console_gfx import ConsoleGfx

current_image = []

def displayWelcome():
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

def displayMenuAndReturnChoice():
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")
    
    return int(input("Select a Menu Option: "))

def loadFile():
    filename = input("Enter name of file to load: ")
    ConsoleGfx.load_file(filename)

def loadTestImage():
    global current_image
    current_image = ConsoleGfx.test_image
    print("Test image data loaded.")

def displayCurrentImage():
    global current_image
    ConsoleGfx.display_image(current_image)


def main():
    displayWelcome()
    
    while True:
        userChoice = displayMenuAndReturnChoice()
        if userChoice == 0:
            break
        elif userChoice == 1:
            loadFile()
        elif userChoice == 2:
            loadTestImage()
        elif userChoice == 6:
            displayCurrentImage()
        print()


main()