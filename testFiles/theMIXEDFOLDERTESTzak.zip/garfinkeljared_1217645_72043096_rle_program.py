from console_gfx import ConsoleGfx as CG


def menu():
    global file_name
    global image_data
    image_data = None
    print("RLE Menu")
    print("--------")
    print("0. Exit\n1. Load File\n2. Load Test image\n3. Read RLE String\n4. Read RLE Hex String\n5. Read Data Hex String\n6. Display image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display Hex Flat Data")
    print()
    print("Select a Menu Option: ", end='')
    option_chose = int(input())
    if option_chose == 1:
        print("Enter name of file to load: ", end='')
        image_data = input()
        file_name = CG.load_file(image_data)
        print()
        menu()
    if option_chose == 2:
        print("Test image data loaded.")
        CG.display_image(CG.test_image)
        print()
        menu()
    if option_chose == 6:
        print("Displaying image...")
        CG.display_image(file_name)
        print()
        menu()


image_data = None
print("Welcome to the RLE image encoder.")
print()
print("Displaying Spectrum Image:")
CG.display_image(CG.test_rainbow)
print()
menu()



