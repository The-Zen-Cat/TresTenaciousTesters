from console_gfx import ConsoleGfx
#from console_gfx.ConsoleGfx import test_rainbow

loadedImage = []


                             
def main():
    
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    while True:
        print('\nRLE Menu\n--------')
        print('0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image\n7. Display Image\n8. Display Hex RLE Data\n9. Display Hex Flat Data\n')
        option = input('Select a menu option: ')
        if option == '0':
            exit()
            
        elif option == '1':
            filename = input('Enter name of file to load: ')
            loadedImage = ConsoleGfx.load_file(filename)

            
        elif option == '2':
            
            loadedImage = ConsoleGfx.test_image
            print('Test Image data loaded\n')
            
        elif option == '3':
            print('3')
            
        elif option == '4':
            print('3')
            
        elif option == '5':
            print('3')
            
        elif option == '6':
            ConsoleGfx.display_image(loadedImage)
            
        elif option == '7':
            print('3')
            
        elif option == '8':
            print('3')






main()
