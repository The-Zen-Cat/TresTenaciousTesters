from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow);
ConsoleGfx.display_image(ConsoleGfx.test_rainbow);
'''

def count_runs(flat):
    pass


if __name__ == '__main__':
    image_data = None;
    print('Welcome to the RLE image encoder!');
    print('Displaying Spectrum Image:');
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow);

    menu = -1;
    while menu != 0:
        print('RLE Menu');
        print('--------');
        print('0. Exit');
        print('1. Load File');
        print('2. Load Test Image');
        print('6. Display Image' +'\n');
        menu = int(input('Select a Menu Option: '));
        if menu == 1:
            filename = input('Enter name of file to load: ')
            file_data = ConsoleGfx.load_file(filename);
        elif menu == 2:
            image_data = ConsoleGfx.test_image;
        elif menu == 6:
            ConsoleGfx.display_image(image_data);
        elif menu == 0:
            break;
        else:
            print('Error! Invalid input.');









