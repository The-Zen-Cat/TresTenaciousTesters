from console_gfx import ConsoleGfx

#print(ConsoleGfx.test_rainbow)
#ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

def count_runs(flat):
    pass


if __name__ == '__main__':
#main program
 image_data = None
print("Welcome to the RLE image encoder!\n")
print("Displaying the Spectrum Image: ")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

menu = -1
while menu != 0:
  print("\n\nRLE Menu\n--------")
  print("0. Exit")
  print("1. Load File")
  print("2. Load Test Image")
  print("3. Read RLE String")
  print("4. Read RLE Hex String")
  print("5. Read Data Hex String")
  print("6. Display Image")
  print("7. Display RLE String")
  print("8. Display Hex RLE Data")
  print("9. Display Hex Flat Data\n")
  num = int(input('Select Menu Option: '))

if num == 1:
  filename = input('Insert File Name: ')
  def load_file(filename):
    file_data = []
    with open(filename, 'rb') as my_file:
      contents = my_file.read()

      for c in contents:
        file_data += [c]

      my_file.close()

    return file_data
  ConsoleGfx.load_file(filename)
  image_data = filename

if num == 2:
  ConsoleGfx.test_image = image_data

if num == 6:
  def display_image(image_data):
    ConsoleGfx.display_image2(image_data, ConsoleGfx.default_top, ConsoleGfx.default_up_left,
                              ConsoleGfx.default_up_right, ConsoleGfx.default_start,
                              ConsoleGfx.default_end, ConsoleGfx.default_bottom, ConsoleGfx.default_low_left,
                              ConsoleGfx.default_low_right)
