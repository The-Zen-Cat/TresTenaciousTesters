from console_gfx import ConsoleGfx

option = None
image_data = None


def main():
    image_data = None

    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print_menu()

def print_menu():
    global image_data
    print('\nRLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data\n')
    option = int(input("Select a Menu Option: "))

    if option == 0:
        quit()

    if option == 1:
        filename = input('Enter name of file to load: ')
        image_data = ConsoleGfx.load_file(filename)
        print_menu()

    if option == 2:
        image_data = ConsoleGfx.test_image
        print('Test image data loaded.')
        print_menu()

    if option == 6:
        if image_data != None:
            ConsoleGfx.display_image(image_data)
            print_menu()


if option == 1:
    ConsoleGfx.load_file(input('Enter name of file to load: '))

if __name__ == '__main__':
    main()
