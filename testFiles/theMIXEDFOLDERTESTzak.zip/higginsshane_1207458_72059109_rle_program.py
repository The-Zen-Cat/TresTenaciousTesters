from console_gfx import ConsoleGfx


def main():

    menu_input = -1

    print("Welcome to the RLE image encoder!")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    image_data = None

    while menu_input != 0:

        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display RLE Hex Data")
        print("9. Display Hex Flat Data")

        print("Select a Menu Option:")

        menu_input = int(input())

        if menu_input == 0:
            exit()

        elif menu_input == 1:
            print("Enter name of file to load:")
            image_data = ConsoleGfx.load_file(input())

        elif menu_input == 2:
            print("Test image data loaded.")
            image_data = ConsoleGfx.test_image

        elif menu_input == 6:
            ConsoleGfx.display_image(image_data)


main()
