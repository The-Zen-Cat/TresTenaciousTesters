from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''

# function definitions
def count_runs(flats):
    pass

if __name__ == '__main__':
    # main
    image_date = None
    # 1. welcome messages
    print("Welcome to RLE image encoder!")
    # 2. display rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    menu = 1
    # keep prompting
    while menu != 0:
        # menu option
        print("RLE Menu\n-------- \n0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE HEX String\n5. "
              "Read Data HEX String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display HEX "
              "Flat Data")
        print("Select a Menu Option:")
        # option 1
        menu = int(input())
        if menu == 1:
            fileName = input("Enter the name of the file to load: ")
            image_data = ConsoleGfx.load_file(fileName)
        elif menu == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded")
        elif menu == 6:
           ConsoleGfx.display_image(image_data)
