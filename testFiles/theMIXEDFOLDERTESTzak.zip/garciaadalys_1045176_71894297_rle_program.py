from console_gfx import ConsoleGfx


if __name__ == '__main__':
    # main program
    image_data = None

    # 1. welcome messages
    print('Welcome to the RLE image encoder!')
    print()
    print('Displaying Spectrum Image:')

    # 2. display test_image
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    print()
    print()

    # 3. while loop to keep prompting user to choose an option
    menu = True
    while menu:
        print('RLE Menu \n--------')
        print('0. Exit \n1. Load File \n2. Load Test Image \n3. Read RLE String\n'
              '4. Read RLE Hex String \n5. Read Data Hex String \n6. Display Image\n'
              '7. Display RLE String \n8. Display Hex RLE Data \n9. Display Hex Flat Data\n')

        # 4. prompt user for menu option
        menu_input = int(input('Select a Menu Option: '))

        # OPTION 0 - Exit
        # Figured it was an easy step, so I just included it
        if menu_input == 0:
            menu = False

        # OPTION 1 - Load File
        elif menu_input == 1:
            # I put everything in one line to make things shorter
            # For the future, should I store the inputted file to a variable?
            # Are we going to use said variable later in the project?
            image_data = ConsoleGfx.load_file(input('Enter name of files to load: '))

        # OPTION 2 - Load Test Image
        elif menu_input == 2:
            print('Test image data loaded. \n')
            image_data = ConsoleGfx.test_image

        # OPTION 6 - Display Image
        elif menu_input == 6:
            print('Displaying image...')
            ConsoleGfx.display_image(image_data)
