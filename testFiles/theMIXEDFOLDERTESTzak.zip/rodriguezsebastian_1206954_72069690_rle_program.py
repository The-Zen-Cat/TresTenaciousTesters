from console_gfx import ConsoleGfx as CG


def print_menu():
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')


def count_runs(flat):
    pass

if __name__ == '__main__':
    # main program
    image_data = None
    print('Welcome to the RLE image encoder!')
    print('Displaying Spectrum Image:')
    CG.display_image(CG.test_rainbow)
    print()

    menu = -1
    while menu != 0
        def load_file(testfiles)
            file

