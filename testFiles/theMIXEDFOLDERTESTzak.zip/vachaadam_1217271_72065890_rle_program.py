from console_gfx import ConsoleGfx

'''print(ConsoleGfx.test_rainbow)

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)'''


def count_runs(flat):
    pass


if __name__ == '__main__':
    image_data = None
    print('Welcome to the RLE image encoder!')
    print()
    print('Displaying Spectrum Image:')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()

    # use while loop to keep prompting the user to choose a menu option
menu = -1
while menu != 0:
    print()
    print('RLE Menu')
    print('-' * 8)
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE HEX String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex Rle Data')
    print('9. Display Hex Flat Data')
    print()
    menu_option = int(input('Select a Menu Option: '))
    if menu_option == 0:
        menu = 0
        break
    elif menu_option == 1:
        filename = input('Enter name of file to load: ')
        image_data = ConsoleGfx.load_file(filename)
        continue
    elif menu_option == 2:
        image_data = ConsoleGfx.test_image
        print('Test image data loaded.')
        continue
    elif menu_option == 3:
        pass
    elif menu_option == 4:
        pass
    elif menu_option == 5:
        pass
    elif menu_option == 6:
        ConsoleGfx.display_image(image_data)
        continue
    elif menu_option == 7:
        pass
    elif menu_option == 8:
        pass
    elif menu_option == 9:
        pass

    # prompt user for menu option
# option 1
# load file and store the data inside the image_data
# prompt for file name
# call ConsoleGfx.load_file(filename) and store returned file

# option 2
# store ConsoleGfx.test_image in image_data

# option 6
# call display_image in ConsoleGfx on image_data
