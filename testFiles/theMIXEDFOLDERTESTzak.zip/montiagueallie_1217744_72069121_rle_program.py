from console_gfx import ConsoleGfx
def main():
    gfx = ConsoleGfx
    print('Welcome to the RLE image encoder!')
    print('Displaying Spectum Image:')
    print(gfx.test_rainbow)
    
    while True:
        print('RLE Menu')
        print('-------')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8. Display Hex RLE Data')
        print('9. Displat Hex Flat Data')

        menu_option = input("Select a Menu Option:")

        while True:
            if menu_option == '1':
                filename = input('Enter name of file to load:')
                print(gfx.load_file(filename))
                image_data = filename
                break
            elif menu_option == '2':
                print("Test image data loaded.")
                image_data = gfx.test_image
                break
            elif menu_option == '6':
                if image_data!= None:
                    gfx.display_image(image_data)
                else:   
                    print("Displaying image...")
                    gfx.display_image
                break
            elif menu_option == '0' :
                exit
            else:
                print('Error! Invalid input.')
                break

main()

