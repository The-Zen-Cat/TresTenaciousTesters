from console_gfx import ConsoleGfx

image_data = None
print("Welcome to the RLE image encoder!\n")
print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

while True:
    print()
    print("RLE Menu\n"
          "--------\n"
          "0. Exit\n"
          "1. Load File\n"
          "2. Load Test Image\n"
          "3. Read RLE String\n"
          "4. Read RLE Hex String\n"
          "5. Read Data Hex String\n"
          "6. Display Image\n"
          "7. Display RLE String\n"
          "8. Display Hex RLE Data\n"
          "9. Display Hex Flat Data\n")
    menu_option = int(input("Select a Menu Option:", ))

    if menu_option == 0:
        exit()

    elif menu_option == 1:
        filename = input("Enter name of file to load:", )
        image_data = ConsoleGfx.load_file(filename)

    elif menu_option == 2:
        print("Test image data loaded.")
        image_data = ConsoleGfx. test_image

    elif menu_option == 3:
        print(None)

    elif menu_option == 4:
        print(None)

    elif menu_option == 5:
        print(None)

    elif menu_option == 6:
        print("Displaying image...")
        if image_data is None:
            print("(no data)")
        else:
            ConsoleGfx.display_image(image_data)

    elif menu_option == 7:
        print("RLE representation:", None)

    elif menu_option == 8:
        print("RLE hex values:", None)

    elif menu_option == 9:
        print("Flat hex values:", None)

    else:
        print("Error! Invalid input.")
