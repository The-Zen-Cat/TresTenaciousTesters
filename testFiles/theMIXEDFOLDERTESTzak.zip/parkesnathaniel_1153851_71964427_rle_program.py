from console_gfx import ConsoleGfx

if __name__ == "__main__":

    running = True
    image_data = None
    print("Welcome to the RLE image encoder!")

    while running:

        print("Displaying Spectrum Image:")
        ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read RLE Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")

        option = int(input("Select a Menu Option: "))

        if option == 0:
            running = False
            continue

        elif option == 1:
            user_file = input("Enter name of file to load: ")
            ConsoleGfx.load_file(user_file)
            image_data = user_file

        elif option == 2:
            test_image = ConsoleGfx.test_image
            image_data = test_image
            print("Test image data loaded.")

        elif option == 6:
            print("Displaying image...")
            if image_data == None:
                print("(no data)")
            else:
                ConsoleGfx.display_image(image_data)
