import console_gfx

ConsoleGfx = console_gfx.ConsoleGfx

if __name__ == '__main__':
    run = True
    print('Welcome to the RLE image encoder!')
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data')
    print('')
    print('Select a Menu Option:')
    option = input()


    def print_menu():
        print('RLE Menu')
        print('--------')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8. Display Hex RLE Data')
        print('9. Display Hex Flat Data')
        print('')
        print('Select a Menu Option:')


    while run == True:

        if option == '1':
            print('Name the file to load')
            filename = input()
            ConsoleGfx.load_file(filename)
            print_menu()
        if option == '2':
            filename = ConsoleGfx.test_image
            print_menu()
            option = input()
        if option == '6':
            ConsoleGfx.display_image(filename)
            print_menu()
            option = input()
    run = False
