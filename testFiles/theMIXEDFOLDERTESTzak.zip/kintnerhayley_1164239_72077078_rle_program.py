from console_gfx import ConsoleGfx

''' 
Example for how to display images from ConsoleGfx from the lecture 
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''

# function definitions
def count_runs(flat):
    pass


if __name__ == "__main__":
    # main program
    image_data = None

    # 1. welcome message
    print("Welcome to the RLE image encoder! \n")

    # 2. display the color test rainbow
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. use while loop to keep prompting user to choose menu option
    menu = -1
    while menu != 0:
        # display menu
        print("\nRLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. Read RLE String")
        print("4. Read Rle Hex String")
        print("5. Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex Flat Data\n")

        # 4. prompt user for menu option
        menu = int(input("Select a Menu Option: "))

        # option 1
        if menu == 1:
            # prompt for the file name
            filename = input("Enter name of file to load: ")
            # load file and store the data inside image_data
            image_data = ConsoleGfx.load_file(filename)

        # option 2
        if menu == 2:
            # store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        # option 6
        if menu == 6:
            if image_data == None:
                print("There is no image to print")
                continue
            # display user selected image
            print("Displaying image...")
            ConsoleGfx.display_image(image_data)