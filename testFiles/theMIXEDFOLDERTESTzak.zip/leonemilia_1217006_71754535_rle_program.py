from console_gfx import ConsoleGfx

'''
print(ConsoleGfx.test_rainbow)
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''


def menu():
    print("RLE Menu")
    print("-" * 8)
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")
    print()


# function definitions
def count_runs(flat):
    pass


if __name__ == '__main__':
    # main program
    image_data = None
    # welcome messages
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    # display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. Use while loop to keep prompting the user to choose a menu option
    print()
    menu()
    menu = True
    while menu:
        # 4. prompt the user for menu option
        print("Select a Menu Option: ", end="")
        menu_selection = int(input())
        if menu_selection == 1:
            print("Enter name of file to load: ", end="")
            file_name = str(input())
            image_data = ConsoleGfx.load_file(str(file_name))
            # if option 1
            # load file and store data inside image_data
            # prompt for the file name
            # call ConsoleGfx.load_file(filename) and store returned value in image_data
        elif menu_selection == 2:
            ConsoleGfx.test_image
            print("Test image data loaded.")
        # option 2
            # store ConsoleGfx.test_image in image_data
        elif menu_selection == 6:
            # option 6
            # call display_image in ConsoleGfx on image_data
            ConsoleGfx.display_image(image_data)
