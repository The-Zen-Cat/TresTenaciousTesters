from console_gfx import ConsoleGfx

# function definitions

if __name__ == '__main__':
    # main program
    image_data = None
    # welcome message print
    # display the test_rainbow
print('Welcome to the RLE image encoder!\n')

print('Displaying Spectrum Image:')
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

menu_choice = -1

while menu_choice != 0:  # 3. use while loop to keep prompting the user to choose a menu option

    print('')
    print('')
    print('RLE Menu')
    print('--------')
    print('0. Exit')
    print('1. Load File')
    print('2. Load Test Image')
    print('3. Read RLE String')
    print('4. Read RLE Hex String ')
    print('5. Read Data Hex String')
    print('6. Display Image')
    print('7. Display RLE String')
    print('8. Display Hex RLE Data')
    print('9. Display Hex Flat Data\n')

    menu_choice = int(input('Select a Menu Option: '))

    if menu_choice == 1:
        filename = (input('Enter name of file to load: '))
        ConsoleGfx.load_file(filename)  # testfiles/gator.gfx
        image_data = ConsoleGfx.load_file(filename)
        # image_data = ConsoleGfx.load_file(image_data)
        # return ConsoleGfx.load_file(image_data)

    if menu_choice == 2:
        print(f'Test image data loaded.')
        image_data = ConsoleGfx.test_image

    '''if menu_choice == 3:
        var_3 = (input('Enter an RLE string to be decoded: '))

    if menu_choice == 4:
        var_4 = (input('Enter a hex string golding RLE data: '))

    if menu_choice == 5:
        var_5 = (input('Enter the hex string holding flat data: ')) '''

    if menu_choice == 6:
        ConsoleGfx.display_image(image_data)

    '''if menu_choice == 7:
        print(f'')

    if menu_choice == 8:
        print(f'RLE hex values: ')

    if menu_choice == 9:
        print('Flat hex values:') '''

    # ----notes from lecture-----
    # 4. prompt the user for menu options (load file w/ ConsoleGfx.load_file and prompt user for file name (look at
    # 25 min mark)

    # option 1
    # load the file and store the data inside image_data
    # prompt for the file name
    # call ConsoleGfx.load_file() and store returned value in image_data

    # option 2
    # store ConsoleGfx.test_image in image_data

    # option 6
    # call display image in ConsoleGfx on image_data
