from console_gfx import ConsoleGfx
# function definitions

def to_hex_string(data):
    pass
def count_runs(flat_data):
    pass
def encode_rle(flat_data):
    pass
def get_decoded_length(rle_data):
    pass
def decode_rle(rle_data):
    pass
def string_to_data(data_string):
    pass
def to_rle_string(rle_data):
    pass
def string_to_rle(rle_string):
    pass
def printMenu():
    print("\nRLE Menu\n--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data\n")
    print("Select a Menu Option:")


if __name__ == '__main__':
    imageData = None
    menuOption = -1
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    while menuOption != 0:
        printMenu()
        menuOption = int(input())
        # displays menu, spectrum image, and prompts user for menuOption
        if menuOption == 1:
            # call ConsoleGfx.load_file(filename) and store return value in imageData
            fileName = input("Enter name of file to load: ")
            imageData = ConsoleGfx.load_file(fileName)
        if menuOption == 2:
            # store Console.Gfx.test_image in imageData
            imageData = ConsoleGfx.test_image
            print("Test image data loaded.")
        if menuOption == 6:
            # call display_image in ConsoleGfx on imageData
            print("Displaying image...")
            ConsoleGfx.display_image(imageData)