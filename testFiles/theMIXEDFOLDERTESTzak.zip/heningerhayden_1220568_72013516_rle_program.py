import console_gfx

console = console_gfx.ConsoleGfx

# console.display_image(console.load_file("P2 - Image Files/fsu.gfx"))


def print_menu():
    print("""
RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data""")


file = ""


if __name__ == "__main__":
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image: ")
    console.display_image(console.test_rainbow)
    while True:
        print_menu()
        print()
        option = int(input("Select Menu Option: "))
        if option == 0:
            break
        elif option == 1:
            file1 = input("Enter name of file to load: ")
            file = console.load_file(file1)
        elif option == 2:
            file = console.test_image
            print("\nTest Image Data Loaded")
        elif option == 6:
            print()
            console.display_image(file)

