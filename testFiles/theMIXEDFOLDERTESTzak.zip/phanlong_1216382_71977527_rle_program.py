from console_gfx import ConsoleGfx

if __name__ == '__main__':
    # 1. welcome message
    print('''Welcome to the RLE image encoder!
    
Displaying Spectrum Image: ''')

    # 2. display the rainbow spectrum
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. display a menu and prompt user to choose an option
    image_data = None
    choice = -1
    while choice != 0:
        print('''

RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data
''')
        # a prompt to ask user's choice
        choice = int(input("Sect a Menu Option: "))

        # option 1 - load file
        if choice == 1:
            filename = input("Enter name of file to load: ")   # prompt to ask user to input the name of a file
            image_data = ConsoleGfx.load_file(filename)   # store the file's data in the image_data

        # option 2 - load test image
        if choice == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        # option 6 - Display image
        if choice == 6:
            ConsoleGfx.display_image(image_data)




