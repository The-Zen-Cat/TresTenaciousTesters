from console_gfx import ConsoleGfx as cgfx




def count_runs(flat):
    pass


def load_file(filename):
    file_data = []
    with open(filename, 'rb') as my_file:

        contents = my_file.read()

        for c in contents:
            file_data += [c]

        my_file.close()

    return file_data


if __name__ == '__main__':
    image_data = None
    rleString = None
    print('Welcome to the RLE image encoder!\n')
    print('Displaying Spectrum Image:')
    cgfx.display_image(cgfx.test_rainbow)

    selection = -1
    while selection != 0:
        print('\n\nRLE Menu')
        print('--------')
        print('0. Exit')
        print('1. Load File')
        print('2. Load Test Image')
        print('3. Read RLE String')
        print('4. Read RLE Hex String')
        print('5. Read Data Hex String')
        print('6. Display Image')
        print('7. Display RLE String')
        print('8. Display Hex RLE Data')
        print('9. Display Hex Flat Data')
        selection = int(input('\nSelect a Menu Option: '))
        if selection == 1:
            filename = input('Enter name of file to load: ')
            image_data = cgfx.load_file(filename)
        if selection == 2:
            image_data = cgfx.test_image
            print('Test image data loaded.')
        if selection == 3:
            rleString = ('Enter an RLE string to be decoded: ')
        if selection == 4:
            pass
        if selection == 5:
            pass
        if selection == 6:
            print('Displaying image...')
            if image_data == None:
                print('(no data)')
                break
            cgfx.display_image(image_data)
        if selection == 7:
            pass
        if selection == 8:
            pass
        if selection == 9:
            pass
        if selection <= -1:
            print('Error! Invalid input.')
        if selection >= 10:
            print('Error! Invalid input.')
    else:
        exit()
