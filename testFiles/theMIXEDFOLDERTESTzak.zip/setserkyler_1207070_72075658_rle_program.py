import console_gfx
loaded_image = []
def main():
    global loaded_image
    print('Welcome to the RLE image encoder!')
    print('\nDisplaying Spectrum Image:')
    console_gfx.ConsoleGfx.display_image(console_gfx.ConsoleGfx.test_rainbow)
    print('\n\nRLE Menu')
    print('--------')
    print('0. Exit\n1. Load File\n2. Test Image\n3. Read RLE String\n'
          '4. Read RLE Hex String\n5. Read Dtat Hex String\n6. Display'
          ' Image\n7. Display RLE String\n8. Display Hex RLE Dta\n9. D'
          'isplay Hex Flat Data')
    num = int(input('Select a menu Option: '))
    if num < 0 or num > 9:
        print('Choose a number between 0 and 9.')
    if num == 0:
        return False
    if num == 1:
        loaded_image = console_gfx.ConsoleGfx.load_file(input('Enter name of file to load: '))
    if num == 2:
        print('Test image data loaded.')
        console_gfx.ConsoleGfx.display_image(console_gfx.ConsoleGfx.test_image)
    if num == 6:
        console_gfx.ConsoleGfx.display_image(loaded_image)
    return True
while main():
    main()