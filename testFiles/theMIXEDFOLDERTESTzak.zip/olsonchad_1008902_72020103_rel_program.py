#09-27-22. Coding setup with Dr. Lisha. Reminder to switch Editor to CS1 when taking screenshots. Chad Olson
from testfiles.console_gfx import ConsoleGfx


'''
print(ConsoleGfx.test_rainbow)

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
'''
# define functions outside the if statement
def count_runs(flat):
    pass


if __name__ == '__main__':
    # main
    image_data = None
    print("Welcome to the RLE image encoder!")
    print("Displaying Spectrum Image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    # 3. use while loop to keep prompting the user to choose a menu option
    user_menu_choice = -1
    while user_menu_choice != 0:
        pass
        # 4. prompt the user for menu option
        print("RLE Menu")
        print("--------")
        print("0. Exit")
        print("1. Load File")
        print("2. Load Test Image")
        print("3. RLE String")
        print("4. Read RLE Hex String")
        print("5.Read Data Hex String")
        print("6. Display Image")
        print("7. Display RLE String")
        print("8. Display Hex RLE Data")
        print("9. Display Hex Flat Data")
        print()

        user_menu_choice = int(input("Select a Menu Option: "))

        if user_menu_choice == 1:  # option 1
            user_file_choice = str(input("Enter name of file to load: "))
            image_data = ConsoleGfx.load_file(user_file_choice)  # NEED HELP WITH THIS. KEEPS GETTING FILE NOT FOUND
            continue
            # load file and store the data inside image_data
                # prompt for the file name
                # call Console.Gfx.load_file(file_name) and store returned value in image_data

        if user_menu_choice == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")
            print()
            continue
            # store Console.Gfx.test_image in image data

        if user_menu_choice == 6: # option 6
            if image_data == None:
                print("No image data available. Please load file or Test image")
                print()
                continue
            print("Displaying image...")
            ConsoleGfx.display_image(image_data)
            image_data = None
            continue
            # call display_image in Console.Gfx on image_data

