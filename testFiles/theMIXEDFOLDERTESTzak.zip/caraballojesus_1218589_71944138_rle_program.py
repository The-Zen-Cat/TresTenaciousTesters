from console_gfx import ConsoleGfx


# Defining functions

def menu():
    print()
    print("RLE Menu")
    print("-" * 8)
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")
    print("9. Display Hex Flat Data")
    print()
    selection_in_function = int(input("Select a Menu Option: "))
    return selection_in_function


if __name__ == "__main__":

    # Initializing variables

    selection = -1
    image_data = 0

    # Welcome screen

    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    print(ConsoleGfx.display_image(ConsoleGfx.test_rainbow))
    print()
    while selection != 0:
        selection = menu()

        # Loading a file

        if selection == 1:
            file_name = input("Enter name of file to load: ")
            image_data = ConsoleGfx.load_file(file_name)

        # Loading the test image

        if selection == 2:
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        # Displaying the image

        if selection == 6:
            print("Displaying image...")
            if image_data != 0:
                ConsoleGfx.display_image(image_data)
            else:
                print("(no data)")
