from console_gfx import ConsoleGfx



def main():
    print("")
    print("RLE Menu")
    print("-"*8)
    print("0. Exit\n1. Load File\n2. Load Test Image\n3. Read RLE String\n4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image\n7. Display RLE String\n8. Display Hex RLE Data\n9. Display HEX Flat Data\n")
    return int(input("Select a Menu Option: "))


image_data = None
print("Welcome to the RLE image encoder!\n")
print("Displaying Spectrum Image:")
ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

while True:
    user_selection = main()
    if user_selection == 1:
        testfiles = input("Enter name of file to load: ")
        image_data = ConsoleGfx.load_file(testfiles)

    elif user_selection == 2:
        image_data = ConsoleGfx.test_image
        print("Test Image data loaded.")


    elif user_selection == 6:
        print("Displaying image...")
        ConsoleGfx.display_image(image_data)

    elif user_selection == 0:
        exit()
