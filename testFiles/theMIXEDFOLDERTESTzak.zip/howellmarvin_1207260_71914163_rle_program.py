from console_gfx import ConsoleGfx

menu = True


# function definition
def menu_selection():
    print("""
RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String         
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat  Data
""")                         # Menu Options


if __name__ == '__main__':
    image_data = None
    print("Welcome to the RLE image encoder!")
    print(f"\nDisplaying Spectrum image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    # main program
    # Display Test rainbow
    while menu:
        menu_selection()
        option = input("Select Menu Option:")
        if option == "1":  # Option 1
            name = input("File Name: ")  # prompt for file name
            image_data = ConsoleGfx.load_file(name)  # load file and store the data inside image_data
        if option == "2":  # Option 2
            image_data = ConsoleGfx.test_image  # store Console.Gfx.test_image in image data
        if option == "6":  # Option 6
            ConsoleGfx.display_image(image_data)  # Call display_image in ConsoleGFX on image_data
