from console_gfx import ConsoleGfx

#function definitions

if __name__ == "__main__":
    image_data = None  # store value of image_data for future use

    print("Welcome to the RLE image encoder!\nDisplaying spectrum image:")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    menu_run = True  # store boolean value for the while loop
    while menu_run:
        print("\nRLE Menu\n--------\n0. Exit\n1. Load file\n2. Load Test Image\n3. Read RLE String")  # display menu
        print("4. Read RLE Hex String\n5. Read Data Hex String\n6. Display Image\n7. Display RLE String")
        print("8. Display Hex RLE Data\n9. Display Hex Flat Data\n")

        menu_choice = int(input("Select a Menu Option: "))  # prompt user to select menu option

        if menu_choice == 0:
            break
        if menu_choice == 1:
            filename = input("Enter name of file to load: ")  # prompt user to input file name
            image_data = ConsoleGfx.load_file(filename)  # store data inside image_data
        if menu_choice == 2:
            image_data = ConsoleGfx.test_image  # store test image inside image_data
            print("Test image data loaded. ")
        if menu_choice == 6:
            ConsoleGfx.display_image(image_data)  # display image_data





