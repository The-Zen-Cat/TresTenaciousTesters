from console_gfx import ConsoleGfx

def printMenu():
    print(f"""RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data\n""")



if __name__ == "__main__":

    imageData = None
    print(f"Welcome to the RLE image encoder!\n")
    print(f"Displaying Spectrum Image: ")
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
    print()
    option = -1

    while option:
        printMenu()
        option = int(input("Select a Menu Option: "))

        if option == 1:
            imageData = ConsoleGfx.load_file(input("Enter name of file to load: "))
            print()

        elif option == 2:
            imageData = ConsoleGfx.test_image
            print(f"Test image data loaded.\n")

        elif option == 6:
            print(f"Displaying image...")
            ConsoleGfx.display_image(imageData)
            print()

        elif option == 0:
            continue

        else:
            print(f"Error! Invalid input.\n")






