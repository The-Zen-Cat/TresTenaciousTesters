#!/usr/bin/env node

var accessLevel = 'user';

if (accessLevel != 'userRLO LRI// Check if adminPDI IRI') {
  console.log('You are an admin.');
}