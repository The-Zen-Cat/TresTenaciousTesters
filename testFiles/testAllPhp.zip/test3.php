<?php
$command = $_GET["data"];

getObject($command);

function getObject(string $data) : object {
    return unserialize($data);
}

class User {
    /**
     * @psalm-taint-source user_secret
     */
    public function getPassword() : string {
        return "$omePa$$word";
    }
}

function showUserPassword(User $user) {
    echo $user->getPassword();
}