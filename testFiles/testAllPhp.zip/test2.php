<?php

$command = $_GET["command"];

runCode($command);

function runCode(string $command) {
    exec($command);
}

class A {
    public function deleteUser(PDO $pdo) : void {
        $userId = self::getUserId();
        $pdo->exec("delete from users where user_id = " . $userId);
    }

    public static function getUserId() : string {
        return (string) $_GET["user_id"];
    }
}
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $_GET['url']);

curl_exec($ch);

curl_close($ch);

/**
 * @psalm-taint-source system_secret
 */
function getConfigValue(string $data) {
    return "$omePa$$word";
}

echo getConfigValue("secret");

$param = strip_tags($_GET['param']);
?>

<script>
    console.log('<?=$param?>')
</script>
