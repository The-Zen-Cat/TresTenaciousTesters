#Project 2A by Omar Alkadry

#Some code below taken from Dr. Zhou lecture


from console_gfx import ConsoleGfx
"""
print(ConsoleGfx.test_rainbow)

ConsoleGfx.display_image(ConsoleGfx.test_rainbow)
"""

#funtion definitions
def count_runs(flat): #FIXME
    pass

if __name__ == "__main__":
    #main program
    image_data = None
    print("Welcome to the RLE image encoder!\n")
    print("Displaying Spectrum Image:")
    #display the test_rainbow
    ConsoleGfx.display_image(ConsoleGfx.test_rainbow)

    #use while loop to keep prompting the user to choose a menu option
    menu = -1
    while menu !=0:
        print("""
RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data\n""")

        #prompt the user for menu options
        print("Select a Menu Option:", end= " ")
        menu_option = int(input())

        # load file and store the data inside of image_data
        if menu_option == 1:

            #prompt for the file name
            print("Enter name of file to load:", end=" ")
            file_name = input()

            #call ConsoleGfx.load_file(filename) and store returned value in image_data and later use in option 6
            image_data = ConsoleGfx.load_file(file_name)

        elif menu_option == 2:

            #store ConsoleGfx.test_image in image_data
            image_data = ConsoleGfx.test_image
            print("Test image data loaded.")

        elif menu_option == 3:
            print("FIXME")

        elif menu_option == 4:
            print("FIXME")

        elif menu_option == 5:
            print("FIXME")

        elif menu_option == 6:

            #call display_image in ConsoleGfx on image_data
            print("Displaying image...")
            ConsoleGfx.display_image(image_data)

        elif menu_option == 7:
            print("FIXME")

        elif menu_option == 8:
            print("FIXME")

        elif menu_option == 9:
            print("FIXME")

        elif menu_option == 0:
            exit()




