import console_gfx as p2_console

# Create a function to display the menu options to the user
def rle_menu():
    print('''RLE Menu
--------
0. Exit
1. Load File
2. Load Test Image
3. Read RLE String
4. Read RLE Hex String
5. Read Data Hex String
6. Display Image
7. Display RLE String
8. Display Hex RLE Data
9. Display Hex Flat Data''')

def main():
    # Create variables needed for program to run
    user_input = 1
    welcome_state = True

    curr_image = 0
    file_name = "null"

    # Create a while loop to keep track of the user's inputs - if the input equals 0, the program will terminate
    while user_input != 0:
        # Keeps track of if the user has run the program before; if not, displays spectrum image
        if welcome_state == True:
            print("Welcome to the RLE image encoder!")
            print("Displaying Spectrum Image:")
            file_name = p2_console.ConsoleGfx.test_rainbow
            curr_image = p2_console.ConsoleGfx.display_image(file_name)
            welcome_state = False

        # Displays the program menu and asks for input from the user
        rle_menu()
        user_input = int(input("Select a Menu Option: "))

        # Breaks out of the main while loop and terminates program
        if user_input == 0:
            break

        # Takes a user input as to what image to load using the program
        if user_input == 1:
            file_name = str(input("Enter name of file to load: "))
            curr_image = p2_console.ConsoleGfx.load_file(file_name)

        # Loads the test image
        if user_input == 2:
            curr_image = p2_console.ConsoleGfx.test_image
            print("Test image data loaded.")

        # Displays the image data currently stored in curr_image
        if user_input == 6:
            p2_console.ConsoleGfx.display_image(curr_image)

main()