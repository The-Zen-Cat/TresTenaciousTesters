import console_gfx  #this imports the console_gfx module

def menu():         #this defines the menu function, which displays the menu
    print("Welcome to the RLE image encoder!")
    print()
    print("Displaying Spectrum Image:")
    console_gfx.ConsoleGfx.display_image(console_gfx.ConsoleGfx.test_rainbow) #this displays the rainbow
    print()
    print("RLE Menu")
    print("--------")
    print("0. Exit")
    print("1. Load File")
    print("2. Load Test Image")
    print("3. Read RLE String")         #more menu printing
    print("4. Read RLE Hex String")
    print("5. Read Data Hex String")
    print("6. Display Image")
    print("7. Display RLE String")
    print("8. Display Hex RLE Data")    #menu stuff
    print("9. Display Hex Flat Data")
    print()

menu_option = 1             #sets default menu option as 1
while menu_option != 0:     #enters a loop that is only exited if 0 is chosen
    menu()                  #invokes the menu function to print the menu
    menu_option = int(input("Select a Menu Option: "))  #prompts user to pick an option
    if menu_option == 1:        #loads a file if 1 is chosen
        file_name = input("Enter name of file to load:")
        current_image = console_gfx.ConsoleGfx.load_file(file_name)  #sets the current image
    elif menu_option == 2:      #loads the test image if 2 is chosen
        console_gfx.ConsoleGfx.display_image(console_gfx.ConsoleGfx.test_image)
    elif menu_option == 6:      #prints the current image from last time 1 was chosen
        console_gfx.ConsoleGfx.display_image(current_image)