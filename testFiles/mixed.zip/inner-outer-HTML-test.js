foo.innerHTML = input.value;
bar.innerHTML = "<a href='"+url+"'>About</a>";